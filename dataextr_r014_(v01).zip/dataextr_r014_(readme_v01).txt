
File: dataextr_r014_(readme_v01).txt                    {Modified: 06/30/20, Created: 11/22/19, Author: Bill Nunn}

Overview:

     DataExtr utility is used to run queries on raw character delimited data sources (ex: CSV files) based upon a user defined “scope” (ordered subset of fields
     present in the raw data source "schema").  Queries may be refined using a set of optional parms ("query=", “include=”, “exclude=”, “sort=”) applied in the
     order listed.  These parms may be set in "config=<cfg_file>" or on the CLI.  "query=/sort=" parms are "field-specific" meaning they reference field labels
     defined using "schema=|scope=" parms ("sort=" may only reference "scope=" parm labels).  "include=/exclude=" parms are "field-generic" meaning the regular
     expression defined in "[in|ex]clude=" applies to entire row of data (target=schema) or to user defined subset of fields for given data row (target=scope).
     Most queries are achievable using "query=/sort=" parms ("field-specific").  "[in|ex]clude=" parms ("field-generic") are legacy but may be used if desired.
     DataExtr supports 8 field delimiters (", : ; @ # % & =").  Each data row must have the same # of fields.  Delimiters may not be part of any field's data.
     DataExtr’s primary use case is to be able to quickly & easily provide multiple customized reports from the same raw data source (rows=<rows>) to address
     different organizational needs without having to set up and maintain a traditional database environment.

Demos:

     DataExtr utility demos available upon request.  Email bluenunn@gmail.com to arrange.

Repository: https://github.com/bluenunn/Toolchest/

     dataextr_r014_(v01).zip includes:

          - dataextr_r014_(docs_v01).txt                {DataExtr Users Guide: "Option/Parm" definitions, RegEx support}

          - dataextr_r014_(readme_v01).txt              {DataExtr Readme File: sample Syntax, Config, Data, Runs & History}

Sample Syntax:

     # Sample "lexical" sort syntax (Organization Membership):           ("first,last": lexical sorts typically used for non-<decimal> fields)---::::::::::
                                                                                                                                                 ::::::::::
          ./dataextr -di config=config_luna06_csv query='id_#>=10 && continent~north_America || last~mendez' sort="first,last"        # {Run01 ("first,last"):    lexical forward sort}
                                                                                                                                                 ::::::::::
          ./dataextr -di config=config_luna06_csv query='id_#>=10 && continent~north_America || last~mendez' sort="first,last -r"     # {Run02 ("first,last -r"): lexical reverse sort}

     # Sample "[lexical|numeric]" sort syntax (Wine Industry Review): "<Points> vs <Price>" query):     {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          ./dataextr -di  config=config_wine_equ query='Review~mango|orange && points>=89 && price<=40' sort="Points"                 # {Run03 ("Points"):        lexical forward sort}
                                                                                                                                                 ::::::
          ./dataextr -di  config=config_wine_equ query='Review~mango|orange && points>=89 && price<=40' sort="Points -n"              # {Run04 ("Points -n"):     numeric forward sort}
                                                                                                                                                 :::::: ::
          ./dataextr -dfi config=config_wine_equ query='Review~mango|orange && points>=89 && price<=40' sort="Points -n -r"           # {Run05 ("Points -n -r"):  numeric reverse sort}
                     ::::                                                                                                                        :::::: :: ::
                     ::::---("-i": ignore-case)                               ("Points [-n] [-r]": sort flags, "-n" (numeric), "-r" (reverse))---::::::-::-::
                     :::----("-f": fields)                                                                                                       :::::: :: ::
                     ::-----("-d": display)           ("Points [-n] [-r]": [<integer>|<fraction>] sorts are "lexical" if "-n" flag is omitted)---::::::-::-::                                                                                                                   :::::::::::: :: ::
                                                                            ::::::::: ::::::::::
                                                                            :::::::::-::::::::::---(<decimal> fields: <integer> (ex: 1357) or <fraction> (ex: 3.14))

    *Notes: "lexical" sorts (sort= "-n" not set) may run on fields that are "<decimal>" in nature.  If <integer>s in a column have same <#_chars> (ex: 93 70 45 81),
            the sort will return fields in forward numerical sequence (ex: 45 70 81 93) or in reverse numerical sequence (ex: 93 81 70 45) if sort= "-r" flag is set.
            If <#_chars>/field varies (ex: 37 123 5 2578), "lexical" forward sort returns "123 2578 37 5"; whereas "numeric" forward sort returns "5 37 123 2578".
            For adjacent columns of <integer>s where fields in each column have same <#_chars>, "lexical" sort offers advantage of sorting each successive column in
            <numerical> sequence even though it is doing it "lexically"; whereas, numerical sort may "ignore" (e.g. not sort values values in adjacent column(s) in
            the numerical sequence you are expecting).  "Wine Industry Review" (Runs 03-05) illustrate this behavior.   DataExtr History file shows the backend sort
            command run for utility "sort=" parm.  If DataExtr "-t" option is set, backend sort "input/output" temp files are saved and may be used to validate run.
            Run "man sort" to further explore the whimsical nature of the mythical "sort" creature lurking beneath the surface of the Unix host DataExtr is run on.

Sample Config Files:

     # Sample "config=<config>" parm file ($config):          {Runs 01-02: Organization Membership}

          LAPTOP-MOQUDB6E:/tmp $ cat config_luna_csv
          title="Luna Mendez Fan Club"
          rows="rows_luna_csv"
          chart="chart_luna_csv"
          scope="ID_#,First,Last,Birthday,Ht_(ft),Title,Nickname,Region,Country,Continent"
          schema="First,Middle,Last,ID_#,Nickname,Title,Dept,Region,Country,Continent,Birthday,Ht_(ft)"

     # Sample "config=<config>" parm file ($config):          {Runs 03-05: Wine Industry Review}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ cat config_wine_equ
          delim="="
          title="Wine_Review_5k"
          rows="rows_wine_equ_5k"
          chart="chart_wine_equ_5k"
          scope="ID_#,Country,Province,Winery,Variety,Points,Price,Review"
          schema="ID_#,Country,Review,Designation,Points,Price,Province,Region_1,Region_2,Taster_Name,Taster_Twitter,Title,Variety,Winery"

Sample Data Files:

     # Sample "rows=<rows>" raw data file ($rows):            {Runs 01-02: Organization Membership}

          LAPTOP-MOQUDB6E:/tmp $ cat rows_luna_csv
          Ariel,,,11,Doncella de Agua,Disney Princess,Maidens Guild,Watertown,Atlantic Ocean,Atlantis,1983_02-07,5.21
          Bugs,,Bunny,21,Coniglio di Carota,Elmer Nemesis,Looney Tunes,Carrot Patch,USA,North America,1962_08-19,1.3
          Daffy,,Duck,20,Anatra Allegra,Zany Mallard,Looney Tunes,Carrot Patch,USA,North America,1965_04-25,1.27
          Edgar,,Uribe,7,Programador Maestro,IT Warrior,Programmers Guild,Morgan Hill,USA,North America,1995_12-03,5.91
          Elmer,,Fudd,14,Cacciatore di Conigli,Bugs Nemesis,Looney Tunes,Carrot Patch,USA,North America,1958_05-16,5.01
          Jasmine,,,17,Fanciulla di Tappeto Volante,Disney Princess,Maidens Guild,Desert Sands,Middle East,Asia,1987_09-26,4.111
          Jiminy,,Cricket,18,Insetto che Rimbalza,Disney,Geppetto Family,Tuscony,Italy,Europe,1968_01-14,0.092
          Juan,Jesus,Sierra,3,Scriba Reale,Intern,Round Table,Fremont,USA,North America,2002_10-25,5.82
          Max,,Mendez,2,Muscoli a Bizzeffe,Knight,Round Table,Sicily,Italy,Europe,1993_06-30,5.6
          Mike,,Snell,4,Gufo Saggio,,Wizards Guild,Elk Grove,USA,North America,1956_03-28,5.921
          Mulan,,,9,Principessa guerriera,Disney Princess,Royal Court,Beijing,China,Asia,2002_03-13,5.5
          Pinocchio,,,12,Ragazzo di Legno,Nosy,Geppetto Family,Lazio,Italy,Europe,1961_07-07,2.301
          Pocahantas,,,15,Fanciulla Indiana,Disney Princess,Maidens Guild,Enchanted Forest,USA,North America,1999_07-07,05.730
          Porky,,Pig,8,Maiale Porcile,Honored Luau Guest,Looney Tunes,Carrot Patch,USA,North America,1962_07-01,2.04
          Road,,Runner,10,Uccello Veloce,Coyote Nemesis,Looney Tunes,La Paz,Mexico,North America,1976_07-04,2.87
          Luna,,Mendez,1,Zampe Bianche,Princess,Royal Court,Calabria,Italy,Europe,2019_05-31,0.512
          Snow,,White,13,Mela del mio occhio,Disney Princess,Maidens Guild,Enchanted Forest,England,Europe,1952_02-29,5.6
          Speedy,,Gonzales,19,Mouse Molto Veloce,Cats Meow,Looney Tunes,Guadalajara,Mexico,North America,1967_07-12,0.48
          Stacy,,Yem,6,Maestro di Ceramica,IT Warrior,Artisans Guild,San Jose,USA,North America,1961_11-21,5.73
          Wiley,,Coyote,16,Coyote Sventato,Roadrunner Nemesis,Looney Tunes,La Paz,Mexico,North America,1975_03-10,4.021
          William,Evan,Nunn,5,Pescatore a Mosca,Craftsmens Guild,Masses,Redwood City,USA,North America,1958_05-16,6.2

     # Sample "rows=<rows>" raw data file ($rows):            {Runs 03-05: Wine Industry Review}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

         *Notes: Data below from "rows_wine_equ_5k" truncated (<...>).  File "rows_wine_equ_5k" (Runs 03-05) consists 5,017 data rows (e.g. 5,017 wines) from kaggle.com web site.
                 Sample "=" delimited wine data below may be used for Runs 03-05 by removing "<...>" & staging on Unix host along with DataExtr utility & "config_wine_equ" file.
                 Eliminate text edit line wrap on a Macbook with BBEdit @ Macbook App store or BBEdit download site: http://www.barebones.com/products/textwrangler/download.html

          LAPTOP-MOQUDB6E:/tmp $ view rows_wine_equ_5k
          1=Italy=Barbecue spice and teriyaki sauce flavors give the wine a bold, chewy feel.=Missoni=86=21=Sicily & Sardinia=Sicilia====Feudi del Pisciotto 2010 Missoni Cabernet Sauvignon (Sicilia)=Cabernet Sauvignon=Feudi del Pisciotto
          <...>
          224=Greece=Lemon zest, mango and flowers lead the nose on this elegant Malagousia.=M=89=18=Peloponnese===Susan Kostrzewa=@suskostrzewa=Kintonis 2015 M Malagousia (Peloponnese)=Malagousia=Kintonis
          225=Italy=This offers aromas of red berry, leafy underbrush and a whiff of chopped mint.==89=25=Piedmont=Barbera d'Alba Superiore==Kerin Oâ€™Keefe=@kerinokeefe=Mirafiore 2015  Barbera d'Alba Superiore=Barbera=Mirafiore
          <...>
          1507=US=This limited cuvÃ©e is made from the smallest block at the estate vineyard.=Winery Block=91=75=Oregon=Chehalem Mountains=Willamette Valley=Paul Gregutt=@paulgwineÂ =BergstrÃ¶m 2014 Winery Block Pinot Noir (Chehalem Mountains)=Pinot Noir=BergstrÃ¶m
          1508=France=It is a ripe finely structured wine, with great acidity and orange flavors.=ChÃ¢teau des Muraires SÃ©duction=91=29=Provence=CÃ´tes de Provence==Roger Voss=@vossroger=Bernard Magrez 2016 ChÃ¢teau des Muraires SÃ©duction RosÃ© (CÃ´tes de Provence)=RosÃ©=Bernard Magrez
          <...>
          1610=Croatia=Heady aromas of lemon blossom, jasmine and orange peel draw you into the glass.==90=17=Istria===Jeff Jenssen=@worldwineguys=Benvenuti 2012 Malvasia Istriana (Istria)=Malvasia Istriana=Benvenuti
          1611=Argentina=The nose offers both minerally crispness and full-fledged black-fruit aromas.==90=22=Mendoza Province=Perdriel==Michael Schachner=@wineschach=Marchiori & Barraud 2012 Malbec (Perdriel)=Malbec=Marchiori & Barraud
          <...>
          1903=France=It's young and tough now, so give it another year and drink from 2018.=Grande RÃ©serve=84=35=Bordeaux=Bordeaux==Roger Voss=@vossroger=Closerie du Bailli 2016 Grande RÃ©serve  (Bordeaux)=Bordeaux-style Red Blend=Closerie du Bailli
          1904=US=Orange blossom and lemon zest perfume this intensely aromatic dry Riesling.=Reserve Dry=93=29=New York=Seneca Lake=Finger Lakes=Anna Lee C. Iijima==Hermann J. Wiemer 2015 Reserve Dry Riesling (Seneca Lake)=Riesling=Hermann J. Wiemer
          <...>
          2071=Greece=Orange, lemon, vanilla and white flower start this fresh and spicy white.==89=25=Santorini===Susan Kostrzewa=@suskostrzewa=Boutari 2012 Assyrtico (Santorini)=Assyrtico=Boutari
          2072=France=It's attractive for those who like their Champagne soft and easygoing.=Diamant Brut RosÃ©=86=72=Champagne=Champagne==Roger Voss=@vossroger=Vranken NV Diamant Brut RosÃ©  (Champagne)=Champagne Blend=Vranken
          <...>
          2213=US=Sharp cranberry notes and mineral tones lend edge to a lingering finish.=The Savage=92=75=New York=North Fork of Long Island=Long Island=Anna Lee C. Iijima==Anthony Nappa 2013 The Savage Cabernet Sauvignon (North Fork of Long Island)=Cabernet Sauvignon=Anthony Nappa
          2214=US=Flavors of toasted bread with orange marmalade prove warm but tartly dynamic.=Estate=92=39=California=Malibu Coast=South Coast=Matt Kettmann=@mattkettmann=Dolin 2013 Estate Chardonnay (Malibu Coast)=Chardonnay=Dolin
          <...>
          2242=France=Aromatic notes of orange peel and flesh charm on the nose of this wine.=Turckheim=89=15=Alsace=Alsace==Anne KrebiehlÂ MW=@AnneInVino=FranÃ§ois Baur 2015 Turckheim Riesling (Alsace)=Riesling=FranÃ§ois Baur
          2243=US=The interplay between racy Pinot Grigio and riper Viognier is intriguing.=Cantata=89=22=California=Temecula Valley=South Coast=Matt Kettmann=@mattkettmann=Robert Renzoni 2015 Cantata White (Temecula Valley)=White Blend=Robert Renzoni
          <...>
          2839=US=In 2007 the excellent Celilo vineyard serves up a stunning GewÃ¼rztraminer.=Celilo Vineyard=91=18=Oregon=Columbia Gorge (OR)=Oregon Other=Paul Gregutt=@paulgwineÂ =Sineann 2007 Celilo Vineyard GewÃ¼rztraminer (Columbia Gorge (OR))=GewÃ¼rztraminer=Sineann
          2840=US=Still spritzy, very tart and tangy, with orange peel and lemon drop flavors.=Underwood Mountain Vineyard=91=14=Oregon=Columbia Gorge (OR)=Oregon Other=Paul Gregutt=@paulgwineÂ =Viento 2007 Underwood Mountain Vineyard Riesling (Columbia Gorge (OR))=Riesling=Viento
          <...>
          3342=US=Creamy and round, it is buoyed by a fresh sprinkling of orange blossom and rind.=Saralee's Vineyard=90=30=California=Russian River Valley=Sonoma=Virginie Boone=@vboone=Arrowood 2012 Saralee's Vineyard Viognier (Russian River Valley)=Viognier=Arrowood
          3343=US=The results are mixed, with neither grape showing much varietal character.=Recumbent=86=20=Oregon=Oregon=Oregon Other=Paul Gregutt=@paulgwineÂ =Gresser NV Recumbent Red (Oregon)=Red Blend=Gresser
          <...>
          3379=US=The meaty flavors are round and full, providing appeal, finishing a bit warm.=The Rookie=89=50=Washington=Red Mountain=Columbia Valley=Sean P. Sullivan=@wawinereport=Guardian 2014 The Rookie Cabernet Sauvignon (Red Mountain)=Cabernet Sauvignon=Guardian
          3380=Greece=Lemon zest, mango and flowers lead the nose on this elegant Malagousia.=M=89=18=Peloponnese===Susan Kostrzewa=@suskostrzewa=Kintonis 2015 M Malagousia (Peloponnese)=Malagousia=Kintonis
          <...>
          3724=US=Butter, salt, pear and fresh-squeezed orange comprise the leading aromas.==90=17=California=Santa Barbara County=Central Coast=Matt Kettmann=@mattkettmann=Byron 2012 Chardonnay (Santa Barbara County)=Chardonnay=Byron
          3725=France=Peach and pear flavors contrast with orange zest and lively final acidity.=Vieilles Vignes=90=25=Burgundy=Pouilly-FuissÃ©==Roger Voss=@vossroger=Collovray et Terrier 2012 Vieilles Vignes  (Pouilly-FuissÃ©)=Chardonnay=Collovray et Terrier
          <...>
          4223=Slovenia=It's thin and racy in the mouth with flavors of mango, apple and guava.=Yanez=89=18=Å tajerska===Jeff Jenssen=@worldwineguys=Dveri-Pax 2014 Yanez White (Å tajerska)=White Blend=Dveri-Pax
          4224=France=Creamy wood aromas are prominent in this ripe, yellow-fruit-flavored wine.==89=40=Burgundy=Mercurey==Roger Voss=@vossroger=ChÃ¢teau de Santenay 2013  Mercurey=Chardonnay=ChÃ¢teau de Santenay
          <...>
          4423=US=Top lots from Sheridan, Dineen and Meek vineyard grapes go into this reserve.=XY Reserve=94=42=Washington=Yakima Valley=Columbia Valley=Paul Gregutt=@paulgwineÂ =Stevens 2007 XY Reserve Cabernet Sauvignon (Yakima Valley)=Cabernet Sauvignon=Stevens
          4424=US=The fresh-fruit flavors show elements of orange, lime, lemon and peach.=Estate Grown=93=40=California=St. Helena=Napa=Virginie Boone=@vboone=Joseph Phelps 2016 Estate Grown Sauvignon Blanc (St. Helena)=Sauvignon Blanc=Joseph Phelps
          <...>
          4702=US=Cola and cherry-candy flavors carry hints of orange peel and pink grapefruit.=Winemaker's Reserve=89=35=Oregon=Chehalem Mountains=Willamette Valley=Paul Gregutt=@paulgwineÂ =Dion 2010 Winemaker's Reserve Pinot Noir (Chehalem Mountains)=Pinot Noir=Dion
          4703=Portugal=This is a dense and very powerful wine that manages to retain a sense of style.=Monte da Cal Saturnino Grande Reserva=93=45=Alentejano===Roger Voss=@vossroger=Global Wines 2011 Monte da Cal Saturnino Grande Reserva Red (Alentejano)=Portuguese Red=Global Wines
          <...>
          5017=France=A fat style of white wine, with wood and ripe peach and apricot flavors.=Collection=89==France Other=Corse==Roger Voss=@vossroger=Domaine Vico 2010 Collection White (Corse)=White Blend=Domaine Vico

Sample Runs:

     Run01 (sort="first,last"):             {Organization Membership: <alpha> lexical forward sort}

          LAPTOP-MOQUDB6E:/tmp $ ./dataextr -di config=config_luna06_csv query='id_#>=10 && continent~north_America || last~mendez' sort="first,last"

          DataExtr Audit Complete: 2020-05-20_17.29.20_PDT.     {Elapsed (sec): 2}

          DataExtr Return Code: 0           {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 21, #_rec_output ($chart): 9, %_rec_match: 42.9%}

          DataExtr Stage Directory  ($dir): /tmp

          DataExtr History File ($history): /tmp/dataextr_history

          DataExtr Config  File  ($config): /tmp/config_luna06_csv

          DataExtr Input   File    ($rows): /tmp/rows_luna06_csv

          DataExtr Output  File   ($chart): /tmp/chart_luna06

          Luna Mendez Fan Club:

          ID_#  First       Last      Birthday    Ht_(ft)  Title               Nickname               Region            Country  Continent
          21    Bugs        Bunny     1962_08-19  1.3      Elmer_Nemesis       Coniglio_di_Carota     Carrot_Patch      USA      North_America
          20    Daffy       Duck      1965_04-25  1.27     Zany_Mallard        Anatra_Allegra         Carrot_Patch      USA      North_America
          14    Elmer       Fudd      1958_05-16  5.01     Bugs_Nemesis        Cacciatore_di_Conigli  Carrot_Patch      USA      North_America
          1     Luna        Mendez    2019_05-31  0.512    Princess            Zampe_Bianche          Calabria          Italy    Europe
          2     Max         Mendez    1993_06-30  5.6      Knight              Muscoli_a_Bizzeffe     Sicily            Italy    Europe
          15    Pocahantas  [TBD]     1999_07-07  05.730   Disney_Princess     Fanciulla_Indiana      Enchanted_Forest  USA      North_America
          10    Road        Runner    1976_07-04  2.87     Coyote_Nemesis      Uccello_Veloce         La_Paz            Mexico   North_America
          19    Speedy      Gonzales  1967_07-12  0.48     Cats_Meow           Mouse_Molto_Veloce     Guadalajara       Mexico   North_America
          16    Wiley       Coyote    1975_03-10  4.021    Roadrunner_Nemesis  Coyote_Sventato        La_Paz            Mexico   North_America

     Run02 (sort="first,last -r"):          {Organization Membership: <alpha> lexical reverse sort}

          LAPTOP-MOQUDB6E:/tmp $ ./dataextr -di config=config_luna06_csv query='id_#>=10 && continent~north_America || last~mendez' sort="first,last -r"

          DataExtr Audit Complete: 2020-05-20_17.29.44_PDT.     {Elapsed (sec): 2}

          DataExtr Return Code: 0           {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 21, #_rec_output ($chart): 9, %_rec_match: 42.9%}

          DataExtr Stage Directory  ($dir): /tmp

          DataExtr History File ($history): /tmp/dataextr_history

          DataExtr Config  File  ($config): /tmp/config_luna06_csv

          DataExtr Input   File    ($rows): /tmp/rows_luna06_csv

          DataExtr Output  File   ($chart): /tmp/chart_luna06

          Luna Mendez Fan Club:

          ID_#  First       Last      Birthday    Ht_(ft)  Title               Nickname               Region            Country  Continent
          16    Wiley       Coyote    1975_03-10  4.021    Roadrunner_Nemesis  Coyote_Sventato        La_Paz            Mexico   North_America
          19    Speedy      Gonzales  1967_07-12  0.48     Cats_Meow           Mouse_Molto_Veloce     Guadalajara       Mexico   North_America
          10    Road        Runner    1976_07-04  2.87     Coyote_Nemesis      Uccello_Veloce         La_Paz            Mexico   North_America
          15    Pocahantas  [TBD]     1999_07-07  05.730   Disney_Princess     Fanciulla_Indiana      Enchanted_Forest  USA      North_America
          2     Max         Mendez    1993_06-30  5.6      Knight              Muscoli_a_Bizzeffe     Sicily            Italy    Europe
          1     Luna        Mendez    2019_05-31  0.512    Princess            Zampe_Bianche          Calabria          Italy    Europe
          14    Elmer       Fudd      1958_05-16  5.01     Bugs_Nemesis        Cacciatore_di_Conigli  Carrot_Patch      USA      North_America
          20    Daffy       Duck      1965_04-25  1.27     Zany_Mallard        Anatra_Allegra         Carrot_Patch      USA      North_America
          21    Bugs        Bunny     1962_08-19  1.3      Elmer_Nemesis       Coniglio_di_Carota     Carrot_Patch      USA      North_America

     Run03 (sort="Points"):                 {Wine Industry Review: <integer> lexical forward sort}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ ./dataextr -di config=config_wine_equ query='Review~mango|orange && points>=89 && price<=40' sort="Points"

          DataExtr Audit Complete: 2020-05-20_17.30.03_PDT.     {Elapsed (sec): 2}

          DataExtr Return Code: 0           {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 5017, #_rec_output ($chart): 15, %_rec_match: 0.3%}

          DataExtr Stage Directory  ($dir): /tmp

          DataExtr History File ($history): /tmp/dataextr_history

          DataExtr Config  File  ($config): /tmp/config_wine_equ

          DataExtr Input   File    ($rows): /tmp/rows_wine_equ_5k

          DataExtr Output  File   ($chart): /tmp/chart_wine_equ_5k

          Wine_Review_5k:

          ID_#  Country   Province     Winery                Variety            Points  Price  Review
          2242  France    Alsace       FranÃ§ois_Baur        Riesling           89      15     Aromatic_notes_of_orange_peel_and_flesh_charm_on_the_nose_of_this_wine.
          4223  Slovenia  Å tajerska   Dveri-Pax             White_Blend        89      18     It's_thin_and_racy_in_the_mouth_with_flavors_of_mango,_apple_and_guava.
          224   Greece    Peloponnese  Kintonis              Malagousia         89      18     Lemon_zest,_mango_and_flowers_lead_the_nose_on_this_elegant_Malagousia.
          3380  Greece    Peloponnese  Kintonis              Malagousia         89      18     Lemon_zest,_mango_and_flowers_lead_the_nose_on_this_elegant_Malagousia.
          2071  Greece    Santorini    Boutari               Assyrtico          89      25     Orange,_lemon,_vanilla_and_white_flower_start_this_fresh_and_spicy_white.
          4702  US        Oregon       Dion                  Pinot_Noir         89      35     Cola_and_cherry-candy_flavors_carry_hints_of_orange_peel_and_pink_grapefruit.
          3724  US        California   Byron                 Chardonnay         90      17     Butter,_salt,_pear_and_fresh-squeezed_orange_comprise_the_leading_aromas.
          1610  Croatia   Istria       Benvenuti             Malvasia_Istriana  90      17     Heady_aromas_of_lemon_blossom,_jasmine_and_orange_peel_draw_you_into_the_glass.
          3725  France    Burgundy     Collovray_et_Terrier  Chardonnay         90      25     Peach_and_pear_flavors_contrast_with_orange_zest_and_lively_final_acidity.
          3342  US        California   Arrowood              Viognier           90      30     Creamy_and_round,_it_is_buoyed_by_a_fresh_sprinkling_of_orange_blossom_and_rind.
          2840  US        Oregon       Viento                Riesling           91      14     Still_spritzy,_very_tart_and_tangy,_with_orange_peel_and_lemon_drop_flavors.
          1508  France    Provence     Bernard_Magrez        RosÃ©              91      29     It_is_a_ripe_finely_structured_wine,_with_great_acidity_and_orange_flavors.
          2214  US        California   Dolin                 Chardonnay         92      39     Flavors_of_toasted_bread_with_orange_marmalade_prove_warm_but_tartly_dynamic.
          1904  US        New_York     Hermann_J._Wiemer     Riesling           93      29     Orange_blossom_and_lemon_zest_perfume_this_intensely_aromatic_dry_Riesling.
          4424  US        California   Joseph_Phelps         Sauvignon_Blanc    93      40     The_fresh-fruit_flavors_show_elements_of_orange,_lime,_lemon_and_peach.

     Run04 (sort="Points -n"):              {Wine Industry Review: <integer> numeric forward sort}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ ./dataextr -di config=config_wine_equ query='Review~mango|orange && points>=89 && price<=40' sort="Points -n"

          DataExtr Audit Complete: 2020-05-20_17.30.40_PDT.     {Elapsed (sec): 2}

          DataExtr Return Code: 0           {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 5017, #_rec_output ($chart): 15, %_rec_match: 0.3%}

          DataExtr Stage Directory  ($dir): /tmp

          DataExtr History File ($history): /tmp/dataextr_history

          DataExtr Config  File  ($config): /tmp/config_wine_equ

          DataExtr Input   File    ($rows): /tmp/rows_wine_equ_5k

          DataExtr Output  File   ($chart): /tmp/chart_wine_equ_5k

          Wine_Review_5k:

          ID_#  Country   Province     Winery                Variety            Points  Price  Review
          2071  Greece    Santorini    Boutari               Assyrtico          89      25     Orange,_lemon,_vanilla_and_white_flower_start_this_fresh_and_spicy_white.
          2242  France    Alsace       FranÃ§ois_Baur        Riesling           89      15     Aromatic_notes_of_orange_peel_and_flesh_charm_on_the_nose_of_this_wine.
          224   Greece    Peloponnese  Kintonis              Malagousia         89      18     Lemon_zest,_mango_and_flowers_lead_the_nose_on_this_elegant_Malagousia.
          3380  Greece    Peloponnese  Kintonis              Malagousia         89      18     Lemon_zest,_mango_and_flowers_lead_the_nose_on_this_elegant_Malagousia.
          4223  Slovenia  Å tajerska   Dveri-Pax             White_Blend        89      18     It's_thin_and_racy_in_the_mouth_with_flavors_of_mango,_apple_and_guava.
          4702  US        Oregon       Dion                  Pinot_Noir         89      35     Cola_and_cherry-candy_flavors_carry_hints_of_orange_peel_and_pink_grapefruit.
          1610  Croatia   Istria       Benvenuti             Malvasia_Istriana  90      17     Heady_aromas_of_lemon_blossom,_jasmine_and_orange_peel_draw_you_into_the_glass.
          3342  US        California   Arrowood              Viognier           90      30     Creamy_and_round,_it_is_buoyed_by_a_fresh_sprinkling_of_orange_blossom_and_rind.
          3724  US        California   Byron                 Chardonnay         90      17     Butter,_salt,_pear_and_fresh-squeezed_orange_comprise_the_leading_aromas.
          3725  France    Burgundy     Collovray_et_Terrier  Chardonnay         90      25     Peach_and_pear_flavors_contrast_with_orange_zest_and_lively_final_acidity.
          1508  France    Provence     Bernard_Magrez        RosÃ©              91      29     It_is_a_ripe_finely_structured_wine,_with_great_acidity_and_orange_flavors.
          2840  US        Oregon       Viento                Riesling           91      14     Still_spritzy,_very_tart_and_tangy,_with_orange_peel_and_lemon_drop_flavors.
          2214  US        California   Dolin                 Chardonnay         92      39     Flavors_of_toasted_bread_with_orange_marmalade_prove_warm_but_tartly_dynamic.
          1904  US        New_York     Hermann_J._Wiemer     Riesling           93      29     Orange_blossom_and_lemon_zest_perfume_this_intensely_aromatic_dry_Riesling.
          4424  US        California   Joseph_Phelps         Sauvignon_Blanc    93      40     The_fresh-fruit_flavors_show_elements_of_orange,_lime,_lemon_and_peach.

     Run05 (sort="Points -n -r"):           {Wine Industry Review: <integer> numeric reverse sort}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ ./dataextr -dfi config=config_wine_equ query='Review~mango|orange && points>=89 && price<=40' sort="Points -n -r"

          DataExtr Audit Complete: 2020-05-20_17.31.38_PDT.     {Elapsed (sec): 3}

          DataExtr Return Code: 0           {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 5017, #_rec_output ($chart): 15, %_rec_match: 0.3%}

          DataExtr Stage Directory  ($dir): /tmp

          DataExtr History File ($history): /tmp/dataextr_history

          DataExtr Config  File  ($config): /tmp/config_wine_equ

          DataExtr Input   File    ($rows): /tmp/rows_wine_equ_5k

          DataExtr Output  File   ($chart): /tmp/chart_wine_equ_5k

          Wine_Review_5k:

          ID_#  Country   Province     Winery                Variety            Points  Price  Review
          4424  US        California   Joseph_Phelps         Sauvignon_Blanc    93      40     The_fresh-fruit_flavors_show_elements_of_orange,_lime,_lemon_and_peach.
          1904  US        New_York     Hermann_J._Wiemer     Riesling           93      29     Orange_blossom_and_lemon_zest_perfume_this_intensely_aromatic_dry_Riesling.
          2214  US        California   Dolin                 Chardonnay         92      39     Flavors_of_toasted_bread_with_orange_marmalade_prove_warm_but_tartly_dynamic.
          2840  US        Oregon       Viento                Riesling           91      14     Still_spritzy,_very_tart_and_tangy,_with_orange_peel_and_lemon_drop_flavors.
          1508  France    Provence     Bernard_Magrez        RosÃ©              91      29     It_is_a_ripe_finely_structured_wine,_with_great_acidity_and_orange_flavors.
          3725  France    Burgundy     Collovray_et_Terrier  Chardonnay         90      25     Peach_and_pear_flavors_contrast_with_orange_zest_and_lively_final_acidity.
          3724  US        California   Byron                 Chardonnay         90      17     Butter,_salt,_pear_and_fresh-squeezed_orange_comprise_the_leading_aromas.
          3342  US        California   Arrowood              Viognier           90      30     Creamy_and_round,_it_is_buoyed_by_a_fresh_sprinkling_of_orange_blossom_and_rind.
          1610  Croatia   Istria       Benvenuti             Malvasia_Istriana  90      17     Heady_aromas_of_lemon_blossom,_jasmine_and_orange_peel_draw_you_into_the_glass.
          4702  US        Oregon       Dion                  Pinot_Noir         89      35     Cola_and_cherry-candy_flavors_carry_hints_of_orange_peel_and_pink_grapefruit.
          4223  Slovenia  Å tajerska   Dveri-Pax             White_Blend        89      18     It's_thin_and_racy_in_the_mouth_with_flavors_of_mango,_apple_and_guava.
          3380  Greece    Peloponnese  Kintonis              Malagousia         89      18     Lemon_zest,_mango_and_flowers_lead_the_nose_on_this_elegant_Malagousia.
          224   Greece    Peloponnese  Kintonis              Malagousia         89      18     Lemon_zest,_mango_and_flowers_lead_the_nose_on_this_elegant_Malagousia.
          2242  France    Alsace       FranÃ§ois_Baur        Riesling           89      15     Aromatic_notes_of_orange_peel_and_flesh_charm_on_the_nose_of_this_wine.
          2071  Greece    Santorini    Boutari               Assyrtico          89      25     Orange,_lemon,_vanilla_and_white_flower_start_this_fresh_and_spicy_white.

Sample History Files ($history):

     Run04 (sort="Points -n"):              {Wine Industry Review: <integer> numeric forward sort}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ cat /tmp/dataextr_history       # {Run 04 DataExtr "-f" ("fields") option not set, reduces run overhead ("2 vs 3" sec, see Run 05 History file)}

          DataExtr History File: /tmp/dataextr_history

          Audit Timestamp (start):  2020-05-20_17.30.38_PDT

          Command Line: ./dataextr -di config=config_wine_equ query='Review~mango|orange && points>=89 && price<=40' sort="Points -n"

          Data_Source: LAPTOP-MOQUDB6E      {User_ID: bluenunn, OS: Ubuntu 18.04.1 LTS}

          DataExtr Return Code: 0           {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 5017, #_rec_output ($chart): 15, %_rec_match: 0.3%}

          Filters:                          {Order:  "query= (adt_qry)  =>  include= (adt_sch inc)  =>  exclude= (adt_sch exc)  =>  sort= (adt_srt)"}

               RC: 0     "adt_qry" function returned 15 records.

                    adt_qry /tmp/datatmp_chart02_scp /tmp/datatmp_chart03_qry

               RC: 0     "adt_srt" function:

                    sort -t "=" -k6 -n /tmp/datatmp_chart06_jus > /tmp/datatmp_chart07_srt

          DataExtr Stage Directory ($dir): /tmp

          DataExtr Config File  ($config): /tmp/config_wine_equ

          DataExtr Input  File    ($rows): /tmp/rows_wine_equ_5k

          DataExtr Output File   ($chart): /tmp/chart_wine_equ_5k

          Audit Timestamp (finish): 2020-05-20_17.30.40_PDT     {Elapsed (sec): 2}}

     Run05 (sort="Points -n -r"):           {Wine Industry Review: <integer> numeric reverse sort}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ cat /tmp/dataextr_history       # {Run 05 DataExtr "-f" ("fields") option set, increases run overhead ("3 vs 2" sec, see Run 04 History file)}

          DataExtr History File: /tmp/dataextr_history

          Audit Timestamp (start):  2020-05-20_17.31.35_PDT

          Command Line: ./dataextr -dfi config=config_wine_equ query='Review~mango|orange && points>=89 && price<=40' sort="Points -n -r"

          Data_Source: LAPTOP-MOQUDB6E      {User_ID: bluenunn, OS: Ubuntu 18.04.1 LTS}

          DataExtr Return Code: 0           {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 5017, #_rec_output ($chart): 15, %_rec_match: 0.3%}

          Option Settings:      {"0": false, "1": true}     {Option Sources:  (def): default, (cli): CLI}

               "-d" (cli):  1   {display}

               "-f" (cli):  1   {fields}

               "-i" (cli):  1   {ignore-case}

               "-r" (def):  0   {raw}

               "-t" (def):  0   {temporary}

          Parm Values:          {Parm Sources:  (def): default, (cfg): <cfg_file>, (cli): CLI, (sch): scope="$schema"}

                   "dir" (def):  dir=/tmp

                "config" (cli):  config=config_wine_equ

                 "title" (cfg):  title=Wine_Review_5k

                 "delim" (cfg):  delim="="

               "history" (def):  history=dataextr_history

                  "rows" (cfg):  rows=rows_wine_equ_5k

                 "chart" (cfg):  chart=chart_wine_equ_5k

                "schema" (cfg):  schema=ID_#,Country,Review,Designation,Points,Price,Province,Region_1,Region_2,Taster_Name,Taster_Twitter,Title,Variety,Winery

                 "scope" (cfg):  scope=ID_#,Country,Province,Winery,Variety,Points,Price,Review

                "target" (def):  target=scope

                 "query" (cli):  query='Review~mango|orange && points>=89 && price<=40'

               "include" (def):

               "exclude" (def):

                  "sort" (cli):  sort="Points -n -r"

          Filters:                          {Order:  "query= (adt_qry)  =>  include= (adt_sch inc)  =>  exclude= (adt_sch exc)  =>  sort= (adt_srt)"}

               RC: 0     "adt_qry" function returned 15 records.

                    adt_qry /tmp/datatmp_chart02_scp /tmp/datatmp_chart03_qry

               RC: 0     "adt_srt" function:

                    sort -t "=" -k6 -n -r /tmp/datatmp_chart06_jus > /tmp/datatmp_chart07_srt

          DataExtr Stage Directory ($dir): /tmp

          DataExtr Config File  ($config): /tmp/config_wine_equ

          DataExtr Input  File    ($rows): /tmp/rows_wine_equ_5k

          DataExtr Output File   ($chart): /tmp/chart_wine_equ_5k

          Audit Timestamp (finish): 2020-05-20_17.31.38_PDT     {Elapsed (sec): 3}}
