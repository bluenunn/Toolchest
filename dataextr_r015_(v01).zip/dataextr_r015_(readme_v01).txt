
File: dataextr_r015_(readme_v01).txt                    {Modified: 07/22/20, Created: 11/22/19, Author: Bill Nunn}

Overview:

     DataExtr utility is used to run queries on raw character delimited data sources (ex: CSV files) based upon a user defined “scope” (ordered subset of fields
     present in the raw data source "schema").  Queries may be refined using a set of optional parms ("query=", “include=”, “exclude=”, “sort=”) applied in the
     order listed.  These parms may be set in "config=<cfg_file>" or on the CLI.  "query=/sort=" parms are "field-specific" meaning they reference field labels
     defined using "schema=|scope=" parms ("sort=" may only reference "scope=" parm labels).  "include=/exclude=" parms are "field-generic" meaning the regular
     expression defined in "[in|ex]clude=" applies to entire row of data (target=schema) or to user defined subset of fields for given data row (target=scope).
     Most queries are achievable using "query=/sort=" parms ("field-specific").  "[in|ex]clude=" parms ("field-generic") are legacy but may be used if desired.
     DataExtr supports 9 field delimiters ("t , : ; @ # % & =") where "t" is the default delimiter for <Tab> delimited data sources.  Each data row must have
     the same number of fields.  Delimiters may not be part of any field's data.  For "delim=t", <Tab> character may not be part of a field, letter "t" is ok.
     DataExtr’s primary use case is to be able to quickly & easily provide multiple customized reports from the same raw data source (rows=<rows>) to address
     different organizational needs without having to set up and maintain traditional database environments.

Demos:

     DataExtr utility demos available upon request.  Email bluenunn@gmail.com to arrange.

Repository: https://github.com/bluenunn/Toolchest/

     dataextr_r015_(v01).zip includes:

          - dataextr_r015_(docs_v01).txt                {DataExtr Users Guide: "Option/Parm" definitions, RegEx support}

          - dataextr_r015_(readme_v01).txt              {DataExtr Readme File: sample Syntax, Config, Data, Runs & History}

Sample Syntax:

     # Sample "lexical" sort syntax (Organization Membership):           ("first,last": lexical sorts typically used for non-<decimal> fields)---::::::::::
                                                                                                                                                 ::::::::::
          ./dataextr -di config=config_luna_csv query='id_#>=10 && continent~north_America || last~mendez' sort="first,last"          # {Run01 ("first,last"):    lexical forward sort}
                                                                                                                                                 ::::::::::
          ./dataextr -di config=config_luna_csv query='id_#>=10 && continent~north_America || last~mendez' sort="first,last -r"       # {Run02 ("first,last -r"): lexical reverse sort}

     # Sample "[lexical|numeric]" sort syntax (Wine Industry Review): "<Points> vs <Price>" query):     {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          ./dataextr -di  config=config_wine_tab query='Review~guava|hazelnut|maple && points>=89 && price<=40' sort="points"         # {Run03 ("Points"):        lexical forward sort}

          ./dataextr -di  config=config_wine_tab query='Review~guava|hazelnut|maple && points>=89 && price<=40' sort="points -n"      # {Run04 ("Points -n"):     numeric forward sort}

          ./dataextr -dif config=config_wine_tab query='Review~guava|hazelnut|maple && points>=89 && price<=40' sort="points -nr"     # {Run05 ("Points -nr"):    numeric reverse sort}
                     ::::                                                                                                                        :::::: :::
                     ::::---("-i": ignore-case)                               ("Points [-n] [-r]": sort flags, "-n" (numeric), "-r" (reverse))---::::::-:::
                     :::----("-f": fields)                                                                                                       :::::: :::
                     ::-----("-d": display)               ("Points [-nr]": [<integer>|<fraction>] sorts are "lexical" if "-n" flag is omitted)---::::::-:::---("-nr" or "-n -r" works)                                                                                                                   :::::::::::: :: ::
                                                                            ::::::::: ::::::::::
                                                                            :::::::::-::::::::::---(<decimal> fields: <integer> (ex: 1357) or <fraction> (ex: 3.14))

    *Notes: "lexical" sorts (sort= "-n" not set) may run on fields that are "<decimal>" in nature.  If <integer>s in a column have same <#_chars> (ex: 93 70 45 81),
            the sort will return fields in forward numerical sequence (ex: 45 70 81 93) or in reverse numerical sequence (ex: 93 81 70 45) if sort= "-r" flag is set.
            If <#_chars>/field varies (ex: 37 123 5 2578), "lexical" forward sort returns "123 2578 37 5"; whereas "numeric" forward sort returns "5 37 123 2578".
            For adjacent columns of <integer>s where fields in each column have same <#_chars>, "lexical" sort offers advantage of sorting each successive column in
            <numerical> sequence even though it is doing it "lexically"; whereas, numerical sort may "ignore" (e.g. not sort values values in adjacent column(s) in
            the numerical sequence you are expecting).  "Wine Industry Review" (Runs 03-05) illustrate this behavior.   DataExtr History file shows the backend sort
            command run for utility "sort=" parm.  If DataExtr "-t" option is set, backend sort "input/output" temp files are saved and may be used to validate run.
            Run "man sort" to further explore the whimsical nature of the mythical "sort" creature lurking beneath the surface of the Unix host DataExtr is run on.

Sample Config & Data Files (Organization Membership):

     # Sample "config=<config>" parm file ($config):          {Runs 01-02: Organization Membership}

          LAPTOP-MOQUDB6E:/tmp $ cat config_luna_csv
          title="Luna Mendez Fan Club"
          delim=","
          rows="rows_luna_csv"
          chart="chart_luna_csv"
          schema="First,Middle,Last,ID_#,Nickname,Title,Dept,Region,Country,Continent,Birthday,Ht_(ft)"
          scope="ID_#,First,Last,Birthday,Ht_(ft),Title,Nickname,Region,Country,Continent"

     # Sample "rows=<rows>" raw data file ($rows):            {Runs 01-02: Organization Membership}

          LAPTOP-MOQUDB6E:/tmp $ cat rows_luna_csv
          Ariel,,,11,Doncella de Agua,Disney Princess,Maidens Guild,Watertown,Atlantic Ocean,Atlantis,1983_02-07,5.21
          Bugs,,Bunny,21,Coniglio di Carota,Elmer Nemesis,Looney Tunes,Carrot Patch,USA,North America,1962_08-19,1.3
          Daffy,,Duck,20,Anatra Allegra,Zany Mallard,Looney Tunes,Carrot Patch,USA,North America,1965_04-25,1.27
          Edgar,,Uribe,7,Programador Maestro,IT Warrior,Programmers Guild,Morgan Hill,USA,North America,1995_12-03,5.91
          Elmer,,Fudd,14,Cacciatore di Conigli,Bugs Nemesis,Looney Tunes,Carrot Patch,USA,North America,1958_05-16,5.01
          Jasmine,,,17,Fanciulla di Tappeto Volante,Disney Princess,Maidens Guild,Desert Sands,Middle East,Asia,1987_09-26,4.111
          Jiminy,,Cricket,18,Insetto che Rimbalza,Disney,Geppetto Family,Tuscony,Italy,Europe,1968_01-14,0.092
          Juan,Jesus,Sierra,3,Scriba Reale,Intern,Round Table,Fremont,USA,North America,2002_10-25,5.82
          Max,,Mendez,2,Muscoli a Bizzeffe,Knight,Round Table,Sicily,Italy,Europe,1993_06-30,5.6
          Mike,,Snell,4,Gufo Saggio,,Wizards Guild,Elk Grove,USA,North America,1956_03-28,5.921
          Mulan,,,9,Principessa guerriera,Disney Princess,Royal Court,Beijing,China,Asia,2002_03-13,5.5
          Pinocchio,,,12,Ragazzo di Legno,Nosy,Geppetto Family,Lazio,Italy,Europe,1961_07-07,2.301
          Pocahantas,,,15,Fanciulla Indiana,Disney Princess,Maidens Guild,Enchanted Forest,USA,North America,1999_07-07,05.730
          Porky,,Pig,8,Maiale Porcile,Honored Luau Guest,Looney Tunes,Carrot Patch,USA,North America,1962_07-01,2.04
          Road,,Runner,10,Uccello Veloce,Coyote Nemesis,Looney Tunes,La Paz,Mexico,North America,1976_07-04,2.87
          Luna,,Mendez,1,Zampe Bianche,Princess,Royal Court,Calabria,Italy,Europe,2019_05-31,0.512
          Snow,,White,13,Mela del mio occhio,Disney Princess,Maidens Guild,Enchanted Forest,England,Europe,1952_02-29,5.6
          Speedy,,Gonzales,19,Mouse Molto Veloce,Cats Meow,Looney Tunes,Guadalajara,Mexico,North America,1967_07-12,0.48
          Stacy,,Yem,6,Maestro di Ceramica,IT Warrior,Artisans Guild,San Jose,USA,North America,1961_11-21,5.73
          Wiley,,Coyote,16,Coyote Sventato,Roadrunner Nemesis,Looney Tunes,La Paz,Mexico,North America,1975_03-10,4.021
          William,Evan,Nunn,5,Pescatore a Mosca,Craftsmens Guild,Masses,Redwood City,USA,North America,1958_05-16,6.2

Sample Config & Data Files (Wine Industry Review):

     # Sample "config=<config>" parm file ($config):          {Runs 03-05: Wine Industry Review}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ cat config_wine_tab
          title="Wine_Review_17k"
          rows="rows_wine_tab_17k"
          chart="chart_wine_tab_17k"
          scope="ID_#,Country,Province,Winery,Variety,Points,Price,Review"
          schema="ID_#,Country,Review,Designation,Points,Price,Province,Region_1,Region_2,Taster_Name,Taster_Twitter,Title,Variety,Winery"

     # Sample "rows=<rows>" raw data file ($rows):            {Runs 03-05: Wine Industry Review}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

         *Notes: Data below from "rows_wine_tab_17k" truncated (<...>).  File "rows_wine_tab_17k" (Runs 03-05) consists 17,850 data rows (e.g. 17,850 wines) from www.kaggle.com site.
                 Sample "<Tab>" delimited wine data below may be used for Runs 03-05 by removing "<...>" & staging on Unix host along with DataExtr utility & "config_wine_tab" file.
                 Eliminate text edit line wrap on a Macbook with BBEdit @ Macbook App store or BBEdit download site: http://www.barebones.com/products/textwrangler/download.html

          LAPTOP-MOQUDB6E:/tmp $ view rows_wine_tab_17k
          1	Portugal	This is ripe and fruity, a wine that is smooth while still structured.	Avidagos	87	15	Douro			Roger Voss	@vossroger	Quinta dos Avidagos 2011 Avidagos Red (Douro)	Portuguese Red	Quinta dos Avidagos
          <...>
          884	South Africa	An attractive toasted hazelnut flavor lingers well through the finish.	Crocodile's Lair Kaaimansgat	90	26	Overberg			Lauren Buzzeo	@laurbuzz	Bouchard Finlayson 2009 Crocodile's Lair Kaaimansgat Chardonnay (Overberg)	Chardonnay	Bouchard Finlayson
          <...>
          1084	Italy	Aromas of beeswax, orchard fruit and a whiff of hazelnut lift out of the glass.	1909	90	25	Lombardy	Lugana		Kerin Oâ€™Keefe	@kerinokeefe	Ancilla 2016 1909  (Lugana)	Turbiana	Ancilla
          <...>
          1368	Italy	Beyond those aromas are layers of almond skin, ginger, cola and hazelnut.		90	36	Piedmont	Barbaresco				Beni di Batasiolo 2009  Barbaresco	Nebbiolo	Beni di Batasiolo
          <...>
          1999	Slovenia	It's thin and racy in the mouth with flavors of mango, apple and guava.	Yanez	89	18	Å tajerska			Jeff Jenssen	@worldwineguys	Dveri-Pax 2014 Yanez White (Å tajerska)	White Blend	Dveri-Pax
          <...>
          2245	Bulgaria	This Bulgarian Chardonnay has aromas of guava, custard apple and lemon pith.		90	17	Danube River Plains			Jeff Jenssen	@worldwineguys	Chateau Burgozone 2015 Chardonnay (Danube River Plains)	Chardonnay	Chateau Burgozone
          <...>
          3409	US	Notable oak wraps around the fruit, ending with hazelnut and nutmeg.		90	30	California	Russian River Valley	Sonoma	Virginie Boone	@vboone	La Crema 2015 Chardonnay (Russian River Valley)	Chardonnay	La Crema
          <...>
          5277	France	Ripe luscious pear fruit almost has a touch of maple syrup on the nose.	Heimbourg	93	40	Alsace	Alsace		Anne KrebiehlÂ MW	@AnneInVino	Domaine Zind-Humbrecht 2015 Heimbourg Riesling (Alsace)	Riesling	Domaine Zind-Humbrecht
          <...>
          8872	US	The initial flavors are light and fresh, with peach and slight guava.		93	35	California	Santa Maria Valley	Central Coast	Matt Kettmann	@mattkettmann	Presqu'ile 2012 Chardonnay (Santa Maria Valley)	Chardonnay	Presqu'ile
          <...>
          9344	US	A taste of hazelnut expands on the palate to meet creamy Tahitian vanilla.		90	18	California	Russian River Valley	Sonoma	Virginie Boone	@vboone	De Loach 2013 Chardonnay (Russian River Valley)	Chardonnay	De Loach
          <...>
          10473	Italy	It opens with bright aromas of ripe berry, leather, tar, resin and maple syrup.	Semonte Alto	90	26	Veneto	Valpolicella Classico Superiore Ripasso				Venturini Massimino 2008 Semonte Alto  (Valpolicella Classico Superiore Ripasso)	Corvina, Rondinella, Molinara	Venturini Massimino
          <...>
          10716	Austria	The merest touch of apricot caresses the vanilla and hazelnut notes of fine oak.	Kreuzgang	92	39	Wagram			Anne KrebiehlÂ MW	@AnneInVino	Anton Bauer 2015 Kreuzgang Chardonnay (Wagram)	Chardonnay	Anton Bauer
          <...>
          11464	Spain	A classy Sherry with full, attractive hazelnut and peanut oil aromas.	Gobernador Oloroso Seco	90	24	Andalucia	Jerez		Michael Schachner	@wineschach	Hidalgo NV Gobernador Oloroso Seco Palomino (Jerez)	Palomino	Hidalgo
          <...>
          12732	US	This opens with enticing aromas of toasted hazelnut, Key lime and white peach.		91	17	Washington	Columbia Valley (WA)	Columbia Valley	Paul Gregutt	@paulgwineÂ 	Apex 2010 Chardonnay (Columbia Valley (WA))	Chardonnay	Apex
          <...>
          12902	Georgia	It has flavors of clementine, orange, hazelnut, leather and smoke.		89	28	Kakheti			Mike DeSimone	@worldwineguys	Shalauri Cellars 2013 Rkatsiteli (Kakheti)	Rkatsiteli	Shalauri Cellars
          <...>
          13569	Argentina	This is a cuddly, jammy, ripe Malbec with maple, blackberry and oak aromas.	ColecciÃ³n	91	20	Mendoza Province	Mendoza		Michael Schachner	@wineschach	Finca Perdriel 2009 ColecciÃ³n Malbec (Mendoza)	Malbec	Finca Perdriel
          <...>
          15808	Austria	Lovely, hazelnut-scented creaminess signals the use of very well-handled oak.	Satzing	92	40	Thermenregion			Anne KrebiehlÂ MW	@AnneInVino	Johanneshof Reinisch 2014 Satzing Rotgipfler (Thermenregion)	Rotgipfler	Johanneshof Reinisch
          <...>
          17524	US	Light in the glass, it shows guava, jasmine water and a lime-skin tartness.	Unoaked	91	19	California	Monterey	Central Coast	Matt Kettmann	@mattkettmann	Ex 2016 Unoaked Chardonnay (Monterey)	Chardonnay	Ex
          <...>
          17850	Chile	This one has bland aromatics, with only a touch of oak to grasp at.		80	8	CuricÃ³ Valley			Michael Schachner	@wineschach	Millaman 2000 Chardonnay (CuricÃ³ Valley)	Chardonnay	Millaman

Sample Runs:

     Run01 (sort="first,last"):             {Organization Membership: <alpha> lexical forward sort}

          LAPTOP-MOQUDB6E:/tmp $ ./dataextr -di config=config_luna_csv query='id_#>=10 && continent~north_America || last~mendez' sort="first,last"

          DataExtr Audit Complete: 2020-07-22_15.16.52_PDT.     {Elapsed (sec): 2}

          DataExtr Return Code (RC): 0      {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 21, #_rec_output ($chart): 9, %_rec_match: 42.9%}

          DataExtr Stage Directory  ($dir): /tmp

          DataExtr History File ($history): /tmp/dataextr_history

          DataExtr Config  File  ($config): /tmp/config_luna_csv

          DataExtr Input   File    ($rows): /tmp/rows_luna_csv

          DataExtr Output  File   ($chart): /tmp/chart_luna_csv

          Luna Mendez Fan Club:

          ID_#  First       Last      Birthday    Ht_(ft)  Title               Nickname               Region            Country  Continent
          21    Bugs        Bunny     1962_08-19  1.3      Elmer_Nemesis       Coniglio_di_Carota     Carrot_Patch      USA      North_America
          20    Daffy       Duck      1965_04-25  1.27     Zany_Mallard        Anatra_Allegra         Carrot_Patch      USA      North_America
          14    Elmer       Fudd      1958_05-16  5.01     Bugs_Nemesis        Cacciatore_di_Conigli  Carrot_Patch      USA      North_America
          1     Luna        Mendez    2019_05-31  0.512    Princess            Zampe_Bianche          Calabria          Italy    Europe
          2     Max         Mendez    1993_06-30  5.6      Knight              Muscoli_a_Bizzeffe     Sicily            Italy    Europe
          15    Pocahantas  [TBD]     1999_07-07  05.730   Disney_Princess     Fanciulla_Indiana      Enchanted_Forest  USA      North_America
          10    Road        Runner    1976_07-04  2.87     Coyote_Nemesis      Uccello_Veloce         La_Paz            Mexico   North_America
          19    Speedy      Gonzales  1967_07-12  0.48     Cats_Meow           Mouse_Molto_Veloce     Guadalajara       Mexico   North_America
          16    Wiley       Coyote    1975_03-10  4.021    Roadrunner_Nemesis  Coyote_Sventato        La_Paz            Mexico   North_America

     Run02 (sort="first,last -r"):          {Organization Membership: <alpha> lexical reverse sort}

          LAPTOP-MOQUDB6E:/tmp $ ./dataextr -di config=config_luna_csv query='id_#>=10 && continent~north_America || last~mendez' sort="first,last -r"

          DataExtr Audit Complete: 2020-07-22_15.17.21_PDT.     {Elapsed (sec): 2}

          DataExtr Return Code (RC): 0      {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 21, #_rec_output ($chart): 9, %_rec_match: 42.9%}

          DataExtr Stage Directory  ($dir): /tmp

          DataExtr History File ($history): /tmp/dataextr_history

          DataExtr Config  File  ($config): /tmp/config_luna_csv

          DataExtr Input   File    ($rows): /tmp/rows_luna_csv

          DataExtr Output  File   ($chart): /tmp/chart_luna_csv

          Luna Mendez Fan Club:

          ID_#  First       Last      Birthday    Ht_(ft)  Title               Nickname               Region            Country  Continent
          16    Wiley       Coyote    1975_03-10  4.021    Roadrunner_Nemesis  Coyote_Sventato        La_Paz            Mexico   North_America
          19    Speedy      Gonzales  1967_07-12  0.48     Cats_Meow           Mouse_Molto_Veloce     Guadalajara       Mexico   North_America
          10    Road        Runner    1976_07-04  2.87     Coyote_Nemesis      Uccello_Veloce         La_Paz            Mexico   North_America
          15    Pocahantas  [TBD]     1999_07-07  05.730   Disney_Princess     Fanciulla_Indiana      Enchanted_Forest  USA      North_America
          2     Max         Mendez    1993_06-30  5.6      Knight              Muscoli_a_Bizzeffe     Sicily            Italy    Europe
          1     Luna        Mendez    2019_05-31  0.512    Princess            Zampe_Bianche          Calabria          Italy    Europe
          14    Elmer       Fudd      1958_05-16  5.01     Bugs_Nemesis        Cacciatore_di_Conigli  Carrot_Patch      USA      North_America
          20    Daffy       Duck      1965_04-25  1.27     Zany_Mallard        Anatra_Allegra         Carrot_Patch      USA      North_America
          21    Bugs        Bunny     1962_08-19  1.3      Elmer_Nemesis       Coniglio_di_Carota     Carrot_Patch      USA      North_America

     Run03 (sort="Points"):                 {Wine Industry Review: <integer> lexical forward sort}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ ./dataextr -di  config=config_wine_tab query='Review~guava|hazelnut|maple && points>=89 && price<=40' sort="points"

          DataExtr Audit Complete: 2020-07-22_15.17.39_PDT.     {Elapsed (sec): 3}

          DataExtr Return Code (RC): 0      {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 17850, #_rec_output ($chart): 17, %_rec_match: 0.1%}

          DataExtr Stage Directory  ($dir): /tmp

          DataExtr History File ($history): /tmp/dataextr_history

          DataExtr Config  File  ($config): /tmp/config_wine_tab

          DataExtr Input   File    ($rows): /tmp/rows_wine_tab_17k

          DataExtr Output  File   ($chart): /tmp/chart_wine_tab_17k

          Wine_Review_17k:

          ID_#   Country       Province             Winery                  Variety      Points  Price  Review
          1999   Slovenia      Å tajerska           Dveri-Pax               White_Blend  89      18     It's_thin_and_racy_in_the_mouth_with_flavors_of_mango,_apple_and_guava.
          12902  Georgia       Kakheti              Shalauri_Cellars        Rkatsiteli   89      28     It_has_flavors_of_clementine,_orange,_hazelnut,_leather_and_smoke.
          2245   Bulgaria      Danube_River_Plains  Chateau_Burgozone       Chardonnay   90      17     This_Bulgarian_Chardonnay_has_aromas_of_guava,_custard_apple_and_lemon_pith.
          9344   US            California           De_Loach                Chardonnay   90      18     A_taste_of_hazelnut_expands_on_the_palate_to_meet_creamy_Tahitian_vanilla.
          11464  Spain         Andalucia            Hidalgo                 Palomino     90      24     A_classy_Sherry_with_full,_attractive_hazelnut_and_peanut_oil_aromas.
          1084   Italy         Lombardy             Ancilla                 Turbiana     90      25     Aromas_of_beeswax,_orchard_fruit_and_a_whiff_of_hazelnut_lift_out_of_the_glass.
          884    South_Africa  Overberg             Bouchard_Finlayson      Chardonnay   90      26     An_attractive_toasted_hazelnut_flavor_lingers_well_through_the_finish.
          10473  Italy         Veneto               Venturini_Massimino     Corvina      90      26     It_opens_with_bright_aromas_of_ripe_berry,_leather,_tar,_resin_and_maple_syrup.
          3409   US            California           La_Crema                Chardonnay   90      30     Notable_oak_wraps_around_the_fruit,_ending_with_hazelnut_and_nutmeg.
          1368   Italy         Piedmont             Beni_di_Batasiolo       Nebbiolo     90      36     Beyond_those_aromas_are_layers_of_almond_skin,_ginger,_cola_and_hazelnut.
          12732  US            Washington           Apex                    Chardonnay   91      17     This_opens_with_enticing_aromas_of_toasted_hazelnut,_Key_lime_and_white_peach.
          17524  US            California           Ex                      Chardonnay   91      19     Light_in_the_glass,_it_shows_guava,_jasmine_water_and_a_lime-skin_tartness.
          13569  Argentina     Mendoza_Province     Finca_Perdriel          Malbec       91      20     This_is_a_cuddly,_jammy,_ripe_Malbec_with_maple,_blackberry_and_oak_aromas.
          10716  Austria       Wagram               Anton_Bauer             Chardonnay   92      39     The_merest_touch_of_apricot_caresses_the_vanilla_and_hazelnut_notes_of_fine_oak.
          15808  Austria       Thermenregion        Johanneshof_Reinisch    Rotgipfler   92      40     Lovely,_hazelnut-scented_creaminess_signals_the_use_of_very_well-handled_oak.
          8872   US            California           Presqu'ile              Chardonnay   93      35     The_initial_flavors_are_light_and_fresh,_with_peach_and_slight_guava.
          5277   France        Alsace               Domaine_Zind-Humbrecht  Riesling     93      40     Ripe_luscious_pear_fruit_almost_has_a_touch_of_maple_syrup_on_the_nose.

     Run04 (sort="Points -n"):              {Wine Industry Review: <integer> numeric forward sort}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ ./dataextr -di  config=config_wine_tab query='Review~guava|hazelnut|maple && points>=89 && price<=40' sort="points -n"

          DataExtr Audit Complete: 2020-07-22_15.17.54_PDT.     {Elapsed (sec): 3}

          DataExtr Return Code (RC): 0      {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 17850, #_rec_output ($chart): 17, %_rec_match: 0.1%}

          DataExtr Stage Directory  ($dir): /tmp

          DataExtr History File ($history): /tmp/dataextr_history

          DataExtr Config  File  ($config): /tmp/config_wine_tab

          DataExtr Input   File    ($rows): /tmp/rows_wine_tab_17k

          DataExtr Output  File   ($chart): /tmp/chart_wine_tab_17k

          Wine_Review_17k:

          ID_#   Country       Province             Winery                  Variety      Points  Price  Review
          12902  Georgia       Kakheti              Shalauri_Cellars        Rkatsiteli   89      28     It_has_flavors_of_clementine,_orange,_hazelnut,_leather_and_smoke.
          1999   Slovenia      Å tajerska           Dveri-Pax               White_Blend  89      18     It's_thin_and_racy_in_the_mouth_with_flavors_of_mango,_apple_and_guava.
          10473  Italy         Veneto               Venturini_Massimino     Corvina      90      26     It_opens_with_bright_aromas_of_ripe_berry,_leather,_tar,_resin_and_maple_syrup.
          1084   Italy         Lombardy             Ancilla                 Turbiana     90      25     Aromas_of_beeswax,_orchard_fruit_and_a_whiff_of_hazelnut_lift_out_of_the_glass.
          11464  Spain         Andalucia            Hidalgo                 Palomino     90      24     A_classy_Sherry_with_full,_attractive_hazelnut_and_peanut_oil_aromas.
          1368   Italy         Piedmont             Beni_di_Batasiolo       Nebbiolo     90      36     Beyond_those_aromas_are_layers_of_almond_skin,_ginger,_cola_and_hazelnut.
          2245   Bulgaria      Danube_River_Plains  Chateau_Burgozone       Chardonnay   90      17     This_Bulgarian_Chardonnay_has_aromas_of_guava,_custard_apple_and_lemon_pith.
          3409   US            California           La_Crema                Chardonnay   90      30     Notable_oak_wraps_around_the_fruit,_ending_with_hazelnut_and_nutmeg.
          884    South_Africa  Overberg             Bouchard_Finlayson      Chardonnay   90      26     An_attractive_toasted_hazelnut_flavor_lingers_well_through_the_finish.
          9344   US            California           De_Loach                Chardonnay   90      18     A_taste_of_hazelnut_expands_on_the_palate_to_meet_creamy_Tahitian_vanilla.
          12732  US            Washington           Apex                    Chardonnay   91      17     This_opens_with_enticing_aromas_of_toasted_hazelnut,_Key_lime_and_white_peach.
          13569  Argentina     Mendoza_Province     Finca_Perdriel          Malbec       91      20     This_is_a_cuddly,_jammy,_ripe_Malbec_with_maple,_blackberry_and_oak_aromas.
          17524  US            California           Ex                      Chardonnay   91      19     Light_in_the_glass,_it_shows_guava,_jasmine_water_and_a_lime-skin_tartness.
          10716  Austria       Wagram               Anton_Bauer             Chardonnay   92      39     The_merest_touch_of_apricot_caresses_the_vanilla_and_hazelnut_notes_of_fine_oak.
          15808  Austria       Thermenregion        Johanneshof_Reinisch    Rotgipfler   92      40     Lovely,_hazelnut-scented_creaminess_signals_the_use_of_very_well-handled_oak.
          5277   France        Alsace               Domaine_Zind-Humbrecht  Riesling     93      40     Ripe_luscious_pear_fruit_almost_has_a_touch_of_maple_syrup_on_the_nose.
          8872   US            California           Presqu'ile              Chardonnay   93      35     The_initial_flavors_are_light_and_fresh,_with_peach_and_slight_guava.

     Run05 (sort="Points -nr"):             {Wine Industry Review: <integer> numeric reverse sort}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ ./dataextr -dif config=config_wine_tab query='Review~guava|hazelnut|maple && points>=89 && price<=40' sort="points -nr"

          DataExtr Audit Complete: 2020-07-22_15.18.20_PDT.     {Elapsed (sec): 4}

          DataExtr Return Code (RC): 0      {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 17850, #_rec_output ($chart): 17, %_rec_match: 0.1%}

          DataExtr Stage Directory  ($dir): /tmp

          DataExtr History File ($history): /tmp/dataextr_history

          DataExtr Config  File  ($config): /tmp/config_wine_tab

          DataExtr Input   File    ($rows): /tmp/rows_wine_tab_17k

          DataExtr Output  File   ($chart): /tmp/chart_wine_tab_17k

          Wine_Review_17k:

          ID_#   Country       Province             Winery                  Variety      Points  Price  Review
          8872   US            California           Presqu'ile              Chardonnay   93      35     The_initial_flavors_are_light_and_fresh,_with_peach_and_slight_guava.
          5277   France        Alsace               Domaine_Zind-Humbrecht  Riesling     93      40     Ripe_luscious_pear_fruit_almost_has_a_touch_of_maple_syrup_on_the_nose.
          15808  Austria       Thermenregion        Johanneshof_Reinisch    Rotgipfler   92      40     Lovely,_hazelnut-scented_creaminess_signals_the_use_of_very_well-handled_oak.
          10716  Austria       Wagram               Anton_Bauer             Chardonnay   92      39     The_merest_touch_of_apricot_caresses_the_vanilla_and_hazelnut_notes_of_fine_oak.
          17524  US            California           Ex                      Chardonnay   91      19     Light_in_the_glass,_it_shows_guava,_jasmine_water_and_a_lime-skin_tartness.
          13569  Argentina     Mendoza_Province     Finca_Perdriel          Malbec       91      20     This_is_a_cuddly,_jammy,_ripe_Malbec_with_maple,_blackberry_and_oak_aromas.
          12732  US            Washington           Apex                    Chardonnay   91      17     This_opens_with_enticing_aromas_of_toasted_hazelnut,_Key_lime_and_white_peach.
          9344   US            California           De_Loach                Chardonnay   90      18     A_taste_of_hazelnut_expands_on_the_palate_to_meet_creamy_Tahitian_vanilla.
          884    South_Africa  Overberg             Bouchard_Finlayson      Chardonnay   90      26     An_attractive_toasted_hazelnut_flavor_lingers_well_through_the_finish.
          3409   US            California           La_Crema                Chardonnay   90      30     Notable_oak_wraps_around_the_fruit,_ending_with_hazelnut_and_nutmeg.
          2245   Bulgaria      Danube_River_Plains  Chateau_Burgozone       Chardonnay   90      17     This_Bulgarian_Chardonnay_has_aromas_of_guava,_custard_apple_and_lemon_pith.
          1368   Italy         Piedmont             Beni_di_Batasiolo       Nebbiolo     90      36     Beyond_those_aromas_are_layers_of_almond_skin,_ginger,_cola_and_hazelnut.
          11464  Spain         Andalucia            Hidalgo                 Palomino     90      24     A_classy_Sherry_with_full,_attractive_hazelnut_and_peanut_oil_aromas.
          1084   Italy         Lombardy             Ancilla                 Turbiana     90      25     Aromas_of_beeswax,_orchard_fruit_and_a_whiff_of_hazelnut_lift_out_of_the_glass.
          10473  Italy         Veneto               Venturini_Massimino     Corvina      90      26     It_opens_with_bright_aromas_of_ripe_berry,_leather,_tar,_resin_and_maple_syrup.
          1999   Slovenia      Å tajerska           Dveri-Pax               White_Blend  89      18     It's_thin_and_racy_in_the_mouth_with_flavors_of_mango,_apple_and_guava.
          12902  Georgia       Kakheti              Shalauri_Cellars        Rkatsiteli   89      28     It_has_flavors_of_clementine,_orange,_hazelnut,_leather_and_smoke.

Sample History Files ($history):

     Run04 (sort="Points -n"):              {Wine Industry Review: <integer> numeric forward sort}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ cat /tmp/dataextr_history       # {Run 04 DataExtr "-f" ("fields") option not set, reduces run overhead ("3 vs 4" sec, see Run 05 History file)}

          DataExtr History File: /tmp/dataextr_history

          Audit Timestamp (start):  2020-07-22_15.17.51_PDT

          Command Line: ./dataextr -di config=config_wine_tab query='Review~guava|hazelnut|maple && points>=89 && price<=40' sort="points -n"

          Data_Source: LAPTOP-MOQUDB6E      {User_ID: bluenunn, OS: Ubuntu 18.04.1 LTS}

          DataExtr Return Code (RC): 0      {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 17850, #_rec_output ($chart): 17, %_rec_match: 0.1%}

          Filters:                          {Order:  "query= (adt_qry)  =>  include= (adt_sch inc)  =>  exclude= (adt_sch exc)  =>  sort= (adt_srt)"}

               RC: 0     "adt_qry" function returned 17 records.

                    adt_qry /tmp/datatmp_chart02_scp /tmp/datatmp_chart03_qry

               RC: 0     "adt_srt" function:

                    sort -t $'\t' -k6 -n /tmp/datatmp_chart06_jus > /tmp/datatmp_chart07_srt

          DataExtr Stage Directory ($dir): /tmp

          DataExtr Config File  ($config): /tmp/config_wine_tab

          DataExtr Input  File    ($rows): /tmp/rows_wine_tab_17k

          DataExtr Output File   ($chart): /tmp/chart_wine_tab_17k

          Audit Timestamp (finish): 2020-07-22_15.17.54_PDT     {Elapsed (sec): 3}}

     Run05 (sort="Points -nr"):             {Wine Industry Review: <integer> numeric reverse sort}          {Data_Source: https://www.kaggle.com/zynicide/wine-reviews}

          LAPTOP-MOQUDB6E:/tmp $ cat /tmp/dataextr_history       # {Run 05 DataExtr "-f" ("fields") option set, increases run overhead ("4 vs 3" sec, see Run 04 History file)}

          DataExtr History File: /tmp/dataextr_history

          Audit Timestamp (start):  2020-07-22_15.18.16_PDT

          Command Line: ./dataextr -dif config=config_wine_tab query='Review~guava|hazelnut|maple && points>=89 && price<=40' sort="points -nr"

          Data_Source: LAPTOP-MOQUDB6E      {User_ID: bluenunn, OS: Ubuntu 18.04.1 LTS}

          DataExtr Return Code (RC): 0      {"0": no errors found, "<non-zero>": errors detected (check History file)}

          DataExtr Audit Overview:          {#_rec_input ($rows): 17850, #_rec_output ($chart): 17, %_rec_match: 0.1%}

          Option Settings:      {"0": false, "1": true}     {Option Sources:  (def): default, (cli): CLI}

               "-d" (cli):  1   {display}

               "-f" (cli):  1   {fields}

               "-i" (cli):  1   {ignore-case}

               "-r" (def):  0   {raw}

               "-t" (def):  0   {temporary}

          Parm Values:          {Parm Sources:  (def): default, (cfg): <cfg_file>, (cli): CLI, (sch): scope="$schema"}

                   "dir" (def):  dir=/tmp

                "config" (cli):  config=config_wine_tab

                 "title" (cfg):  title=Wine_Review_17k

                 "delim" (def):  delim="t"

               "history" (def):  history=dataextr_history

                  "rows" (cfg):  rows=rows_wine_tab_17k

                 "chart" (cfg):  chart=chart_wine_tab_17k

                "schema" (cfg):  schema=ID_#,Country,Review,Designation,Points,Price,Province,Region_1,Region_2,Taster_Name,Taster_Twitter,Title,Variety,Winery

                 "scope" (cfg):  scope=ID_#,Country,Province,Winery,Variety,Points,Price,Review

                "target" (def):  target=scope

                 "query" (cli):  query='Review~guava|hazelnut|maple && points>=89 && price<=40'

               "include" (def):

               "exclude" (def):

                  "sort" (cli):  sort="points -nr"

          Filters:                          {Order:  "query= (adt_qry)  =>  include= (adt_sch inc)  =>  exclude= (adt_sch exc)  =>  sort= (adt_srt)"}

               RC: 0     "adt_qry" function returned 17 records.

                    adt_qry /tmp/datatmp_chart02_scp /tmp/datatmp_chart03_qry

               RC: 0     "adt_srt" function:

                    sort -t $'\t' -k6 -nr /tmp/datatmp_chart06_jus > /tmp/datatmp_chart07_srt

          DataExtr Stage Directory ($dir): /tmp

          DataExtr Config File  ($config): /tmp/config_wine_tab

          DataExtr Input  File    ($rows): /tmp/rows_wine_tab_17k

          DataExtr Output File   ($chart): /tmp/chart_wine_tab_17k

          Audit Timestamp (finish): 2020-07-22_15.18.20_PDT     {Elapsed (sec): 4}}
